package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import test.service.*;
import test.vo.*;

public class RegisterController implements Controller {
	
public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			String id = req.getParameter("id");
			String pwd = req.getParameter("pwd");
			String name = req.getParameter("name");
			String mail = req.getParameter("mail");
			String phone = req.getParameter("phone");
			
			
			if(id.isEmpty()||pwd.isEmpty()||name.isEmpty()||phone.isEmpty()) {
				req.setAttribute("msg", "항목들을 전부 입력하세요!");
			
				HttpUtil.forward(req,resp,"/Register.jsp");
				
				
			}else {
			Member member = new Member();
			member.setId(id);
			member.setPwd(pwd);
			member.setName(name);
			member.setMail(mail);
			member.setPhone(phone);
			
			//service 객체
			MemberService service = MemberService.getInstance();
			service.memberInsert(member);
			
			req.setAttribute("msg", "회원가입이 완료되었습니다!");
			HttpUtil.forward(req,resp,"/Register.jsp");
			}
	}

}
