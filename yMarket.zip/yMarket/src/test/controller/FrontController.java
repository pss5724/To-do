package test.controller;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class FrontController extends HttpServlet {
	
	HashMap<String,Controller> list =null;
	
	public void init(ServletConfig config) throws ServletException{
		list = new HashMap<String,Controller>();
		list.put("/register.do", new RegisterController());
		list.put("/announcement.do", new AnnouncementController());
		list.put("/board.do", new BoardController());
		list.put("/demand.do", new DemandController());
		list.put("/free.do", new FreeController());
		list.put("/announcementlist.do", new AnnouncementListController());
		list.put("/boardlist.do", new BoardListController());
		list.put("/demandlist.do", new DemandListController());
		list.put("/freelist.do", new FreeListController());
		list.put("/announcementdetail.do", new AnnouncementDetailController());
		list.put("/boarddetail.do", new BoardDetailController());
		list.put("/demanddetail.do", new DemandDetailController());
		list.put("/freedetail.do", new FreeDetailController());
		list.put("/login.do", new LoginController());
		list.put("/announcementdelete.do", new AnnouncementDeleteController());
		list.put("/boarddelete.do", new BoardDeleteController());
		list.put("/demanddelete.do", new DemandDeleteController());
		list.put("/freedelete.do", new FreeDeleteController());
		list.put("/memberlist.do", new MemberListController());
		list.put("/memberdelete.do", new MemberDeleteController());
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		String url = req.getRequestURI();
		String cp = req.getContextPath();
		String path = url.substring(cp.length(),url.length());
		
		Controller sc = list.get(path);
		sc.execute(req,resp);
		
	}
	
	
}
