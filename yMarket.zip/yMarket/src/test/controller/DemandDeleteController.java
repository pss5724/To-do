package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import test.service.*;
import test.vo.*;

public class DemandDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int count = Integer.parseInt(req.getParameter("count"));
		
		Demand demand= new Demand();
		demand.setCount(count);
		
		MemberService service = MemberService.getInstance();
		service.demandDelete(demand);
		
	
		HttpUtil.forward(req, resp, "/demand.do");
		
		
	}
	

}
