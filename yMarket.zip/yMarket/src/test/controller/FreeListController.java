package test.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.MemberService;
import test.vo.Free;

public class FreeListController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<Free> free= MemberService.getInstance().FreeList();
		
		req.setAttribute("list", free);
		HttpUtil.forward(req, resp, "/free.jsp");
		
	}

}
