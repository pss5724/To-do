package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import test.service.*;
import test.vo.*;

public class BoardDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int count = Integer.parseInt(req.getParameter("count"));
		
		Board board= new Board();
		board.setCount(count);
		
		MemberService service = MemberService.getInstance();
		service.boardDelete(board);
		
	
		HttpUtil.forward(req, resp, "/board.do");
		
		
	}
	

}
