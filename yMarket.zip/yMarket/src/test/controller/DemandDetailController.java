package test.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.Demand;

public class DemandDetailController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				HttpSession s = req.getSession();
				s.getAttribute("id");
				int count = Integer.parseInt(req.getParameter("count"));
			
				
				
			
				MemberService service = MemberService.getInstance();
				Demand detail =service.DemandDetail(count);
				
				
				req.setAttribute("demand", detail);
				HttpUtil.forward(req, resp, "/demanddetail.jsp");
		
	}

}
