package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import test.service.*;
import test.vo.*;

public class FreeDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int count = Integer.parseInt(req.getParameter("count"));
		
		Free free= new Free();
		free.setCount(count);
		
		MemberService service = MemberService.getInstance();
		service.freeDelete(free);
		
	
		HttpUtil.forward(req, resp, "/free.do");
		
		
	}
	

}
