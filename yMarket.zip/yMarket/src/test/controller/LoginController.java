package test.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.service.MemberService;
import test.vo.Member;

public class LoginController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				String id = req.getParameter("id");
				String pwd = req.getParameter("pwd");
				
				
				
				if(id.equals("")||pwd.equals("")) {
					req.setAttribute("msg", "아이디 비밀번호를 입력해주세요!");
					HttpUtil.forward(req, resp, "/login.jsp");
				}
				
				
		
				MemberService service = MemberService.getInstance();
				Member search =service.login(id);
				
				if(id.equals("admin")&&pwd.equals("1234")) {
					HttpSession s = req.getSession();
					s.setAttribute("id", id);
					HttpUtil.forward(req, resp, "admin.jsp");
				}
			
				if(id.equals(search.getId()) && pwd.equals(search.getPwd())) {
					HttpSession s = req.getSession();
					s.setAttribute("id", id);
					HttpUtil.forward(req, resp, "/main.jsp");
				}
				
				if(!id.equals(search.getId())) {
					req.setAttribute("msg", "아이디를 확인하세요!");
					HttpUtil.forward(req, resp, "/login.jsp");
				}else if(!pwd.equals(search.getPwd())){
					req.setAttribute("msg", "비밀번호를 확인하세요!");
					HttpUtil.forward(req, resp, "/login.jsp");
				}
				
	}

}
