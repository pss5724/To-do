package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import test.service.*;
import test.vo.*;

public class DemandController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession s = req.getSession();
		String id = (String)s.getAttribute("id");
		String title = req.getParameter("title");
		String text = req.getParameter("text");
		String name = req.getParameter("name");
		
		
		
		Demand demand= new Demand();
		
		demand.setId(id);
		demand .setName(name);
		demand .setTitle(title);
		demand .setText(text);
		
		MemberService service = MemberService.getInstance();
		service.Demand(demand);
		
		
		HttpUtil.forward(req, resp, "/demandlist.do");
		
	}

}
