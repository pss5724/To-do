package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import test.service.*;
import test.vo.*;

public class AnnouncementController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession s = req.getSession();
		String id = (String)s.getAttribute("id");
		String title = req.getParameter("title");
		String text = req.getParameter("text");
		String name = req.getParameter("name");
		
		
		
		Announcement announcement = new Announcement();
		
		announcement.setId(id);
		announcement.setName(name);
		announcement.setTitle(title);
		announcement.setText(text);
		
		MemberService service = MemberService.getInstance();
		service.Announcement(announcement);
		
		
		HttpUtil.forward(req, resp, "/announcementlist.do");
		
	}

}
