package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import test.service.*;
import test.vo.*;

public class MemberDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		
		Member member= new Member();
		member.setId(id);
		
		MemberService service = MemberService.getInstance();
		service.MemberDelete(member);
		
		req.setAttribute("id", member.getId());
		HttpUtil.forward(req, resp, "/memberlist.do");
		
		
	}
	

}
