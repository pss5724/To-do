package test.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.MemberService;
import test.vo.Board;

public class BoardListController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<Board> board = MemberService.getInstance().BoardList();
		
		req.setAttribute("list", board);
		HttpUtil.forward(req, resp, "/board.jsp");
		
	}

}
