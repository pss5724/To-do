package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import test.service.*;
import test.vo.*;

public class MemberListController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<Member> list = MemberService.getInstance().list();
		
		req.setAttribute("list", list);
		HttpUtil.forward(req, resp, "/memberlist.jsp");
		
	}

}
