package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import test.service.*;
import test.vo.*;

public class AnnouncementDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int count = Integer.parseInt(req.getParameter("count"));
		
		Announcement announcement= new Announcement();
		announcement.setCount(count);
		
		MemberService service = MemberService.getInstance();
		service.announcementDelete(announcement);
		
	
		HttpUtil.forward(req, resp, "/announcement.do");
		
		
	}
	

}
