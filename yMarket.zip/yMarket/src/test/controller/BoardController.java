package test.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import test.service.*;
import test.vo.*;

public class BoardController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession s = req.getSession();
		String id = (String)s.getAttribute("id");
		String title = req.getParameter("title");
		String text = req.getParameter("text");
		String name = req.getParameter("name");
		
		
		
		Board board = new Board();
		
		board .setId(id);
		board .setName(name);
		board .setTitle(title);
		board .setText(text);
		
		MemberService service = MemberService.getInstance();
		service.Board(board);
		
		
		HttpUtil.forward(req, resp, "/boardlist.do");
		
	}

}
