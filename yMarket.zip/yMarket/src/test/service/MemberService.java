package test.service;

import java.util.ArrayList;

import test.dao.MemberDAO;
import test.vo.Announcement;
import test.vo.Board;
import test.vo.Demand;
import test.vo.Free;
import test.vo.Member;

public class MemberService {
	private static MemberService service = new MemberService();
	
	public MemberDAO dao = MemberDAO.getInstance();
	
	private MemberService() {}
	
	public static MemberService getInstance() {
		return service;
		
	}
	
	public void memberInsert(Member member) {
		dao.memberInsert(member);
	}
	
	public Announcement AnnouncementDetail(int count) {
		return dao.AnnouncementDetail(count);
		
	}
	public Board BoardDetail(int count) {
		return dao.BoardDetail(count);
		
	}
	public Demand DemandDetail(int count) {
		return dao.DemandDetail(count);
		
	}
	public Free FreeDetail(int count) {
		return dao.FreeDetail(count);
		
	}
	public Member login(String id) {
		return dao.login(id);
	}
	
	public void MemberDelete(Member member) {
		dao.MemberDelete(member);
	}
	public void announcementDelete(Announcement announcement) {
		dao.announcementDelete(announcement);
	}
	public void boardDelete(Board board) {
		dao.boardDelete(board);
	}
	public void demandDelete(Demand demand) {
		dao.demandDelete(demand);
	}
	public void freeDelete(Free free) {
		dao.freeDelete(free);
	}
	public ArrayList<Member> list(){
		return dao.list();
	}
	public ArrayList<Announcement> AnnouncementList(){
		return dao.AnnouncementList();
	}
	public ArrayList<Board> BoardList(){
		return dao.BoardList();
	}
	public ArrayList<Demand> DemandList(){
		return dao.DemandList();
	}
	public ArrayList<Free> FreeList(){
		return dao.FreeList();
	}
	public void Announcement(Announcement announcement){
		dao.Announcement(announcement);
	}
	public void Board(test.vo.Board board){
		dao.Board(board);
	}
	public void Demand(Demand demand){
		dao.Demand(demand);
	}
	public void Free(Free free){
		dao.Free(free);
	}
}
