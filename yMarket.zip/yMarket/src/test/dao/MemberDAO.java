package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import test.vo.Announcement;
import test.vo.Board;
import test.vo.Demand;
import test.vo.Free;
import test.vo.Member;

public class MemberDAO {
	private static MemberDAO memberDao = new MemberDAO();
	
	private MemberDAO() {}
	
	public static MemberDAO getInstance() {
		return memberDao;
	}
	
	public Connection getConnection() {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost/pss?serverTimezone=UTC","root", "cs1234");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
	
	
	public void memberInsert(Member member) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("insert into member values(?,?,?,?,?)");
	
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPwd());	
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getMail());
			pstmt.setString(5, member.getPhone());
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public Announcement AnnouncementDetail(int count) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Announcement announcement = null;
		try {
			pstmt = con.prepareStatement("select * from announcement where count=?");
			
			pstmt.setInt(1, count);
			
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				announcement = new Announcement();
				announcement.setCount(rs.getInt(1));
				announcement.setId(rs.getString(2));
				announcement.setTitle(rs.getString(3));
				announcement.setText(rs.getString(4));
				announcement.setName(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return announcement;
	}
	public Board BoardDetail(int count) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Board board= null;
		try {
			pstmt = con.prepareStatement("select * from board where count=?");
			
			pstmt.setInt(1, count);
			
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				board = new Board();
				board.setCount(rs.getInt(1));
				board.setId(rs.getString(2));
				board.setTitle(rs.getString(3));
				board.setText(rs.getString(4));
				board.setName(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return board;
	}
	public Free FreeDetail(int count) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Free free= null;
		try {
			pstmt = con.prepareStatement("select * from free where count=?");
			
			pstmt.setInt(1, count);
			
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				free = new Free();
				free.setCount(rs.getInt(1));
				free.setId(rs.getString(2));
				free.setTitle(rs.getString(3));
				free.setText(rs.getString(4));
				free.setName(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return free;
	}
	public Demand DemandDetail(int count) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Demand demand= null;
		try {
			pstmt = con.prepareStatement("select * from demand where count=?");
			
			pstmt.setInt(1, count);
			
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				demand = new Demand();
				demand.setCount(rs.getInt(1));
				demand.setId(rs.getString(2));
				demand.setTitle(rs.getString(3));
				demand.setText(rs.getString(4));
				demand.setName(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return demand;
	}
	
	public Member login(String id) {
			
			Connection con = this.getConnection();
		
			PreparedStatement pstmt;
			Member member = null;
			try {
				pstmt = con.prepareStatement("select id,pwd from member where id=?");
				pstmt.setString(1, id);	
						
				ResultSet rs = pstmt.executeQuery();
				if(rs.next()) {
					member = new Member();
					member.setId(rs.getString(1));
					member.setPwd(rs.getString(2));
				}
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
			return member;
			
		
		
		
	}
	
	public void MemberDelete(Member member) {
		
		Connection con = this.getConnection();
	
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("delete from member where id=?");
			pstmt.setString(1, member.getId());	
			
		
			
			pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	
	public void announcementDelete(Announcement announcement) {
		
		Connection con = this.getConnection();
	
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("delete from announcement where count=?");
			pstmt.setInt(1, announcement.getCount());	
			
		
			
			pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}

public void boardDelete(Board board) {
		
		Connection con = this.getConnection();
	
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("delete from board where count=?");
			pstmt.setInt(1, board.getCount());	
			
		
			
			pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
public void freeDelete(Free free) {
	
	Connection con = this.getConnection();

	PreparedStatement pstmt;
	try {
		pstmt = con.prepareStatement("delete from free where count=?");
		pstmt.setInt(1, free.getCount());	
		
	
		
		pstmt.executeUpdate();
} catch (SQLException e) {
	e.printStackTrace();
}
}
	

public void demandDelete(Demand demand) {
	
	Connection con = this.getConnection();

	PreparedStatement pstmt;
	try {
		pstmt = con.prepareStatement("delete from demand where count=?");
		pstmt.setInt(1, demand.getCount());	
		
	
		
		pstmt.executeUpdate();
} catch (SQLException e) {
	e.printStackTrace();
}
}


	public ArrayList<Member> list() {
		ArrayList<Member> list = new ArrayList<Member>();
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Member member = null;
		try {
			pstmt = con.prepareStatement("select * from member");
			
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				member = new Member();
				member.setId(rs.getString(1));
				member.setPwd(rs.getString(2));
				member.setName(rs.getString(3));
				
				
				list.add(member);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<Announcement> AnnouncementList() {
		ArrayList<Announcement> list = new ArrayList<Announcement>();
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Announcement a = null;
		try {
			pstmt = con.prepareStatement("select * from announcement");
			
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				a = new Announcement();
				a.setCount(rs.getInt(1));
				a.setId(rs.getString(2));
				a.setTitle(rs.getString(3));
				a.setText(rs.getString(4));
				a.setName(rs.getString(5));
				
				
				
				list.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<Board> BoardList() {
		ArrayList<Board> list = new ArrayList<Board>();
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Board b = null;
		try {
			pstmt = con.prepareStatement("select * from board");
			
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				b = new Board();
				b.setCount(rs.getInt(1));
				b.setId(rs.getString(2));
				b.setTitle(rs.getString(3));
				b.setText(rs.getString(4));
				b.setName(rs.getString(5));
				
				
				
				list.add(b);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<Free> FreeList() {
		ArrayList<Free> list = new ArrayList<Free>();
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Free f = null;
		try {
			pstmt = con.prepareStatement("select * from free");
			
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				f = new Free();
				f.setCount(rs.getInt(1));
				f.setId(rs.getString(2));
				f.setTitle(rs.getString(3));
				f.setText(rs.getString(4));
				f.setName(rs.getString(5));
				
				
				
				list.add(f);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<Demand> DemandList() {
		ArrayList<Demand> list = new ArrayList<Demand>();
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		Demand d = null;
		try {
			pstmt = con.prepareStatement("select * from demand");
			
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				d = new Demand();
				d.setCount(rs.getInt(1));
				d.setId(rs.getString(2));
				d.setTitle(rs.getString(3));
				d.setText(rs.getString(4));
				d.setName(rs.getString(5));
				
				
				
				list.add(d);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public void Announcement(Announcement announcement) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("insert into announcement(id,title,text,name) values(?,?,?,?)");
	
			pstmt.setString(1, announcement.getId());
			pstmt.setString(2, announcement.getTitle());	
			pstmt.setString(3, announcement.getText());
			pstmt.setString(4, announcement.getName());
		
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void Board(test.vo.Board board) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("insert into board(id,title,text,name) values(?,?,?,?)");
	
			pstmt.setString(1, board.getId());
			pstmt.setString(2, board.getTitle());	
			pstmt.setString(3, board.getText());
			pstmt.setString(4, board.getName());
		
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void Demand(Demand demand) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("insert into demand(id,title,text,name) values(?,?,?,?)");
	
			pstmt.setString(1, demand.getId());
			pstmt.setString(2, demand.getTitle());	
			pstmt.setString(3, demand.getText());
			pstmt.setString(4, demand.getName());
		
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void Free(Free free) {
		Connection con = this.getConnection();
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("insert into free(id,title,text,name) values(?,?,?,?)");
	
			pstmt.setString(1, free.getId());
			pstmt.setString(2, free.getTitle());	
			pstmt.setString(3, free.getText());
			pstmt.setString(4, free.getName());
		
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
